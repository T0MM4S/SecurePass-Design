import { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { BiometricUnlock } from './components/BiometricUnlock';
import { OnboardingScreens } from './components/OnboardingScreens';
import { LoginScreen } from './components/LoginScreen';
import { SignupScreen } from './components/SignupScreen';
import { HomeDashboard } from './components/HomeDashboard';
import { AddPassword } from './components/AddPassword';
import { PasswordDetails } from './components/PasswordDetails';
import { EditPassword } from './components/EditPassword';
import { PasswordGenerator } from './components/PasswordGenerator';
import { CategoriesScreen } from './components/CategoriesScreen';
import { CategoryView } from './components/CategoryView';
import { ProfileScreen } from './components/ProfileScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { BreachAlerts } from './components/BreachAlerts';
import { SecurityTips } from './components/SecurityTips';
import { ActivityLog } from './components/ActivityLog';
import { BackupSync } from './components/BackupSync';
import { MasterPasswordReset } from './components/MasterPasswordReset';

export interface Password {
  id: string;
  serviceName: string;
  username: string;
  password: string;
  notes: string;
  category: string;
}

export interface ActivityLogEntry {
  id: string;
  action: 'viewed' | 'edited' | 'added' | 'deleted' | 'login';
  description: string;
  timestamp: Date;
}

export type Screen =
  | 'splash'
  | 'biometric'
  | 'onboarding'
  | 'login'
  | 'signup'
  | 'home'
  | 'add-password'
  | 'password-details'
  | 'edit-password'
  | 'password-generator'
  | 'password-generator-add'
  | 'password-generator-edit'
  | 'categories'
  | 'category-view'
  | 'profile'
  | 'settings'
  | 'breach-alerts'
  | 'security-tips'
  | 'activity-log'
  | 'backup-sync'
  | 'master-password-reset';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [passwords, setPasswords] = useState<Password[]>([
    {
      id: '1',
      serviceName: 'Gmail',
      username: 'john.doe@gmail.com',
      password: 'MySecurePass123!',
      notes: 'Primary email account',
      category: 'Personal',
    },
    {
      id: '2',
      serviceName: 'GitHub',
      username: 'johndoe',
      password: 'DevSecure2024#',
      notes: 'Work repositories',
      category: 'Work',
    },
    {
      id: '3',
      serviceName: 'Instagram',
      username: '@john_doe',
      password: 'Insta!Secure99',
      notes: 'Personal social media',
      category: 'Social',
    },
    {
      id: '4',
      serviceName: 'Chase Bank',
      username: 'john.doe@gmail.com',
      password: 'Bank$ecure456',
      notes: 'Main checking account',
      category: 'Banking',
    },
    {
      id: '5',
      serviceName: 'Netflix',
      username: 'john.doe@gmail.com',
      password: 'Netflix2024!',
      notes: 'Family plan',
      category: 'Personal',
    },
    {
      id: '6',
      serviceName: 'Slack',
      username: 'john@company.com',
      password: 'SlackWork#789',
      notes: 'Company workspace',
      category: 'Work',
    },
  ]);
  const [selectedPassword, setSelectedPassword] = useState<Password | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [userProfile] = useState({
    name: 'John Doe',
    email: 'john.doe@gmail.com',
  });
  const [darkMode, setDarkMode] = useState(true);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(true);
  const [autoBackup, setAutoBackup] = useState(false);
  const [generatedPassword, setGeneratedPassword] = useState('');
  const [returnScreen, setReturnScreen] = useState<Screen>('home');
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([
    {
      id: '1',
      action: 'login',
      description: 'Successful login to SecurePass',
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
    },
    {
      id: '2',
      action: 'viewed',
      description: 'Viewed password for Gmail',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
    },
    {
      id: '3',
      action: 'edited',
      description: 'Updated password for GitHub',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
    },
    {
      id: '4',
      action: 'added',
      description: 'Added new password for Netflix',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
  ]);
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!hasSeenOnboarding) {
        setCurrentScreen('onboarding');
      } else if (biometricEnabled) {
        setCurrentScreen('biometric');
      } else {
        setCurrentScreen('login');
      }
    }, 2500);
    return () => clearTimeout(timer);
  }, [hasSeenOnboarding, biometricEnabled]);

  const addActivityLog = (action: ActivityLogEntry['action'], description: string) => {
    const newEntry: ActivityLogEntry = {
      id: Date.now().toString(),
      action,
      description,
      timestamp: new Date(),
    };
    setActivityLog([newEntry, ...activityLog]);
  };

  const handleAddPassword = (password: Omit<Password, 'id'>) => {
    const newPassword: Password = {
      ...password,
      id: Date.now().toString(),
    };
    setPasswords([...passwords, newPassword]);
    addActivityLog('added', `Added new password for ${password.serviceName}`);
    setGeneratedPassword('');
    setCurrentScreen('home');
  };

  const handleUpdatePassword = (updatedPassword: Password) => {
    setPasswords(
      passwords.map((p) => (p.id === updatedPassword.id ? updatedPassword : p))
    );
    addActivityLog('edited', `Updated password for ${updatedPassword.serviceName}`);
    setGeneratedPassword('');
    setCurrentScreen('password-details');
    setSelectedPassword(updatedPassword);
  };

  const handleDeletePassword = (id: string) => {
    const password = passwords.find((p) => p.id === id);
    setPasswords(passwords.filter((p) => p.id !== id));
    if (password) {
      addActivityLog('deleted', `Deleted password for ${password.serviceName}`);
    }
    setSelectedPassword(null);
    setCurrentScreen('home');
  };

  const handleViewPassword = (password: Password) => {
    setSelectedPassword(password);
    addActivityLog('viewed', `Viewed password for ${password.serviceName}`);
    setCurrentScreen('password-details');
  };

  const handleEditPassword = (password: Password) => {
    setSelectedPassword(password);
    setCurrentScreen('edit-password');
  };

  const handleViewCategory = (category: string) => {
    setSelectedCategory(category);
    setCurrentScreen('category-view');
  };

  const handleGenerateFromAdd = () => {
    setReturnScreen('add-password');
    setCurrentScreen('password-generator-add');
  };

  const handleGenerateFromEdit = () => {
    setReturnScreen('edit-password');
    setCurrentScreen('password-generator-edit');
  };

  const handleUseGeneratedPassword = (password: string) => {
    setGeneratedPassword(password);
    setCurrentScreen(returnScreen);
  };

  const handleLogin = () => {
    addActivityLog('login', 'Successful login to SecurePass');
    setCurrentScreen('home');
  };

  const handleBiometricUnlock = () => {
    addActivityLog('login', 'Unlocked with biometrics');
    setCurrentScreen('home');
  };

  const handleSkipBiometric = () => {
    setCurrentScreen('login');
  };

  const handleOnboardingComplete = () => {
    setHasSeenOnboarding(true);
    if (biometricEnabled) {
      setCurrentScreen('biometric');
    } else {
      setCurrentScreen('login');
    }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen />;
      case 'onboarding':
        return <OnboardingScreens onComplete={handleOnboardingComplete} />;
      case 'biometric':
        return (
          <BiometricUnlock
            onUnlock={handleBiometricUnlock}
            onSkip={handleSkipBiometric}
          />
        );
      case 'login':
        return (
          <LoginScreen
            onLogin={handleLogin}
            onSignup={() => setCurrentScreen('signup')}
          />
        );
      case 'signup':
        return (
          <SignupScreen
            onSignup={handleLogin}
            onBack={() => setCurrentScreen('login')}
          />
        );
      case 'home':
        return (
          <HomeDashboard
            passwords={passwords}
            onAddPassword={() => {
              setGeneratedPassword('');
              setCurrentScreen('add-password');
            }}
            onViewPassword={handleViewPassword}
            onNavigate={setCurrentScreen}
          />
        );
      case 'add-password':
        return (
          <AddPassword
            onSave={handleAddPassword}
            onCancel={() => setCurrentScreen('home')}
            onGeneratePassword={handleGenerateFromAdd}
            generatedPassword={generatedPassword}
            onClearGeneratedPassword={() => setGeneratedPassword('')}
          />
        );
      case 'password-details':
        return selectedPassword ? (
          <PasswordDetails
            password={selectedPassword}
            onEdit={() => handleEditPassword(selectedPassword)}
            onDelete={() => handleDeletePassword(selectedPassword.id)}
            onBack={() => setCurrentScreen('home')}
          />
        ) : null;
      case 'edit-password':
        return selectedPassword ? (
          <EditPassword
            password={selectedPassword}
            onSave={handleUpdatePassword}
            onCancel={() => setCurrentScreen('password-details')}
            onGeneratePassword={handleGenerateFromEdit}
            generatedPassword={generatedPassword}
            onClearGeneratedPassword={() => setGeneratedPassword('')}
          />
        ) : null;
      case 'password-generator':
      case 'password-generator-add':
      case 'password-generator-edit':
        return (
          <PasswordGenerator
            onBack={() => setCurrentScreen(returnScreen)}
            onUsePassword={handleUseGeneratedPassword}
            showUseButton={currentScreen !== 'password-generator'}
          />
        );
      case 'categories':
        return (
          <CategoriesScreen
            passwords={passwords}
            onViewCategory={handleViewCategory}
            onNavigate={setCurrentScreen}
          />
        );
      case 'category-view':
        return (
          <CategoryView
            category={selectedCategory}
            passwords={passwords.filter((p) => p.category === selectedCategory)}
            onViewPassword={handleViewPassword}
            onBack={() => setCurrentScreen('categories')}
          />
        );
      case 'profile':
        return (
          <ProfileScreen
            profile={userProfile}
            onNavigate={setCurrentScreen}
          />
        );
      case 'settings':
        return (
          <SettingsScreen
            darkMode={darkMode}
            twoFactorEnabled={twoFactorEnabled}
            biometricEnabled={biometricEnabled}
            onToggleDarkMode={() => setDarkMode(!darkMode)}
            onToggleTwoFactor={() => setTwoFactorEnabled(!twoFactorEnabled)}
            onToggleBiometric={() => setBiometricEnabled(!biometricEnabled)}
            onNavigate={setCurrentScreen}
          />
        );
      case 'breach-alerts':
        return <BreachAlerts onBack={() => setCurrentScreen('settings')} />;
      case 'security-tips':
        return <SecurityTips onBack={() => setCurrentScreen('settings')} />;
      case 'activity-log':
        return (
          <ActivityLog
            activities={activityLog}
            onBack={() => setCurrentScreen('settings')}
          />
        );
      case 'backup-sync':
        return (
          <BackupSync
            autoBackup={autoBackup}
            onToggleAutoBackup={() => setAutoBackup(!autoBackup)}
            onBack={() => setCurrentScreen('settings')}
          />
        );
      case 'master-password-reset':
        return (
          <MasterPasswordReset
            onSave={() => setCurrentScreen('settings')}
            onBack={() => setCurrentScreen('settings')}
          />
        );
      default:
        return <SplashScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md h-[844px] bg-gray-900 rounded-[3rem] shadow-2xl overflow-hidden relative border-8 border-gray-800">
        <div className="h-full overflow-y-auto">{renderScreen()}</div>
      </div>
    </div>
  );
}

export default App;
