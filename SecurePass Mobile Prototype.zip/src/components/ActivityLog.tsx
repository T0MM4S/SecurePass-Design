import { ArrowLeft, Eye, Edit2, Plus, Trash2, LogIn } from 'lucide-react';
import type { ActivityLogEntry } from '../App';

interface ActivityLogProps {
  activities: ActivityLogEntry[];
  onBack: () => void;
}

const actionLabels: Record<string, string> = {
  viewed: 'Pa fjalëkalimin për',
  edited: 'Përditësoi fjalëkalimin për',
  added: 'Shtoi fjalëkalim të ri për',
  deleted: 'Fshiu fjalëkalimin për',
  login: 'Hyri me sukses në SecurePass',
};

export function ActivityLog({ activities, onBack }: ActivityLogProps) {
  const getActionIcon = (action: ActivityLogEntry['action']) => {
    switch (action) {
      case 'viewed':
        return <Eye className="w-5 h-5 text-blue-400" />;
      case 'edited':
        return <Edit2 className="w-5 h-5 text-yellow-400" />;
      case 'added':
        return <Plus className="w-5 h-5 text-green-400" />;
      case 'deleted':
        return <Trash2 className="w-5 h-5 text-red-400" />;
      case 'login':
        return <LogIn className="w-5 h-5 text-teal-400" />;
      default:
        return <Eye className="w-5 h-5 text-gray-400" />;
    }
  };

  const getActionBg = (action: ActivityLogEntry['action']) => {
    switch (action) {
      case 'viewed':
        return 'bg-blue-500/20';
      case 'edited':
        return 'bg-yellow-500/20';
      case 'added':
        return 'bg-green-500/20';
      case 'deleted':
        return 'bg-red-500/20';
      case 'login':
        return 'bg-teal-500/20';
      default:
        return 'bg-gray-700';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return 'Tani';
    if (minutes < 60) return `${minutes}min më parë`;
    if (hours < 24) return `${hours}orë më parë`;
    if (days < 7) return `${days} ditë më parë`;
    
    return date.toLocaleDateString('sq-AL', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Ditari i Aktivitetit</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-6">
          <p className="text-gray-400">
            Gjurmo të gjitha veprimet e kryera në seifin tënd SecurePass.
          </p>
        </div>

        <div className="space-y-3">
          {activities.map((activity, index) => (
            <div key={activity.id}>
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`${getActionBg(activity.action)} w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0`}>
                    {getActionIcon(activity.action)}
                  </div>
                  {index < activities.length - 1 && (
                    <div className="w-0.5 flex-1 bg-gray-800 my-2 min-h-[20px]"></div>
                  )}
                </div>
                <div className="flex-1 pb-6">
                  <p className="text-gray-100 mb-1">{activity.description}</p>
                  <p className="text-gray-500 text-xs">{formatTime(activity.timestamp)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
