import { useState } from 'react';
import { ArrowLeft, Lock, Eye, EyeOff } from 'lucide-react';
import { PasswordStrengthIndicator } from './PasswordStrength';

interface MasterPasswordResetProps {
  onSave: () => void;
  onBack: () => void;
}

export function MasterPasswordReset({ onSave, onBack }: MasterPasswordResetProps) {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!oldPassword || !newPassword || !confirmPassword) {
      alert('Ju lutemi plotësoni të gjitha fushat');
      return;
    }

    if (newPassword !== confirmPassword) {
      alert('Fjalëkalimet e reja nuk përputhen');
      return;
    }

    if (newPassword.length < 8) {
      alert('Fjalëkalimi i ri duhet të jetë të paktën 8 karaktere i gjatë');
      return;
    }

    // Simulate success
    alert('Fjalëkalimi kryesor u përditësua me sukses!');
    onSave();
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Ndrysho Fjalëkalimin Kryesor</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-6">
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
            <p className="text-yellow-400 text-xs leading-relaxed">
              Kujdes: Ndryshimi i fjalëkalimit tuaj kryesor do të kërkojë që të hyni përsëri. Sigurohu që të mbash mend fjalëkalimin tënd të ri pasi nuk mund të rikuperohet.
            </p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-5">
          <div>
            <label className="block text-gray-300 mb-2">
              Fjalëkalimi Kryesor Aktual <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showOldPassword ? 'text' : 'password'}
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                placeholder="Vendos fjalëkalimin aktual"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
              <button
                type="button"
                onClick={() => setShowOldPassword(!showOldPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showOldPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 mb-2">
              Fjalëkalimi Kryesor i Ri <span className="text-red-400">*</span>
            </label>
            <div className="relative mb-3">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showNewPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Vendos fjalëkalimin e ri"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            {newPassword && <PasswordStrengthIndicator password={newPassword} showDetails={true} />}
          </div>

          <div>
            <label className="block text-gray-300 mb-2">
              Konfirmo Fjalëkalimin e Ri <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Konfirmo fjalëkalimin e ri"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            {confirmPassword && newPassword !== confirmPassword && (
              <p className="text-red-400 text-xs mt-2">Fjalëkalimet nuk përputhen</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors mt-6"
          >
            Ruaj Ndryshimet
          </button>
        </form>
      </div>
    </div>
  );
}
