import { useState, useEffect } from 'react';
import { ArrowLeft, Sparkles } from 'lucide-react';
import { PasswordStrengthIndicator } from './PasswordStrength';
import type { Password } from '../App';

interface AddPasswordProps {
  onSave: (password: Omit<Password, 'id'>) => void;
  onCancel: () => void;
  onGeneratePassword: () => void;
  generatedPassword: string;
  onClearGeneratedPassword: () => void;
}

export function AddPassword({
  onSave,
  onCancel,
  onGeneratePassword,
  generatedPassword,
  onClearGeneratedPassword,
}: AddPasswordProps) {
  const [serviceName, setServiceName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [notes, setNotes] = useState('');
  const [category, setCategory] = useState('Personal');

  useEffect(() => {
    if (generatedPassword) {
      setPassword(generatedPassword);
      onClearGeneratedPassword();
    }
  }, [generatedPassword, onClearGeneratedPassword]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName || !username || !password) {
      alert('Ju lutemi plotësoni të gjitha fushat e kërkuara');
      return;
    }
    onSave({ serviceName, username, password, notes, category });
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Shto Fjalëkalim</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <form onSubmit={handleSave} className="space-y-5">
          <div>
            <label className="block text-gray-300 mb-2">
              Emri i Shërbimit <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={serviceName}
              onChange={(e) => setServiceName(e.target.value)}
              placeholder="p.sh., Gmail, Netflix"
              className="w-full bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div>
            <label className="block text-gray-300 mb-2">
              Emri i Përdoruesit / Email <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Vendos emrin e përdoruesit ose email"
              className="w-full bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div>
            <label className="block text-gray-300 mb-2">
              Fjalëkalimi <span className="text-red-400">*</span>
            </label>
            <div className="flex gap-2 mb-3">
              <input
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Vendos fjalëkalimin"
                className="flex-1 bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
              <button
                type="button"
                onClick={onGeneratePassword}
                className="bg-teal-500 hover:bg-teal-600 text-white px-4 py-3 rounded-xl transition-colors flex items-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
              </button>
            </div>
            {password && <PasswordStrengthIndicator password={password} showDetails={true} />}
          </div>

          <div>
            <label className="block text-gray-300 mb-2">Kategoria</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="Personal">Personal</option>
              <option value="Work">Punë</option>
              <option value="Social">Sociale</option>
              <option value="Banking">Bankare</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-300 mb-2">Shënime (opsionale)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Shto shënime shtesë..."
              rows={4}
              className="w-full bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors"
          >
            Ruaj Fjalëkalimin
          </button>
        </form>
      </div>
    </div>
  );
}