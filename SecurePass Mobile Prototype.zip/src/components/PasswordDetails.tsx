import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, Copy, Edit2, Trash2, Check } from 'lucide-react';
import { PasswordStrengthIndicator } from './PasswordStrength';
import type { Password } from '../App';

interface PasswordDetailsProps {
  password: Password;
  onEdit: () => void;
  onDelete: () => void;
  onBack: () => void;
}

export function PasswordDetails({ password, onEdit, onDelete, onBack }: PasswordDetailsProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState<'username' | 'password' | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleCopy = (text: string, type: 'username' | 'password') => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleDelete = () => {
    if (showDeleteConfirm) {
      onDelete();
    } else {
      setShowDeleteConfirm(true);
      setTimeout(() => setShowDeleteConfirm(false), 3000);
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Detajet e Fjalëkalimit</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="space-y-6">
          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
            <h3 className="text-gray-100 mb-2">{password.serviceName}</h3>
            <span className="inline-block bg-teal-500/20 text-teal-400 px-3 py-1 rounded-lg">
              {password.category}
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-gray-400 mb-2">Emri i Përdoruesit / Email</label>
              <div className="flex gap-2">
                <div className="flex-1 bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 break-all">
                  {password.username}
                </div>
                <button
                  onClick={() => handleCopy(password.username, 'username')}
                  className="bg-gray-800 hover:bg-gray-700 text-teal-400 px-4 py-3 rounded-xl border border-gray-700 transition-colors flex-shrink-0"
                >
                  {copied === 'username' ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <Copy className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-gray-400 mb-2">Fjalëkalimi</label>
              <div className="flex gap-2 mb-3">
                <div className="flex-1 bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700 flex items-center justify-between">
                  <span className="font-mono break-all">
                    {showPassword ? password.password : '••••••••••••'}
                  </span>
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-gray-500 hover:text-gray-300 ml-2 flex-shrink-0"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                <button
                  onClick={() => handleCopy(password.password, 'password')}
                  className="bg-gray-800 hover:bg-gray-700 text-teal-400 px-4 py-3 rounded-xl border border-gray-700 transition-colors flex-shrink-0"
                >
                  {copied === 'password' ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <Copy className="w-5 h-5" />
                  )}
                </button>
              </div>
              <PasswordStrengthIndicator password={password.password} />
            </div>

            {password.notes && (
              <div>
                <label className="block text-gray-400 mb-2">Shënime</label>
                <div className="bg-gray-800 text-gray-100 rounded-xl px-4 py-3 border border-gray-700">
                  {password.notes}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-3 pt-4">
            <button
              onClick={onEdit}
              className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <Edit2 className="w-5 h-5" />
              Ndrysho Fjalëkalimin
            </button>
            <button
              onClick={handleDelete}
              className={`w-full ${
                showDeleteConfirm
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30'
              } py-4 rounded-xl transition-colors flex items-center justify-center gap-2`}
            >
              <Trash2 className="w-5 h-5" />
              {showDeleteConfirm ? 'Konfirmo Fshirjen?' : 'Fshi Fjalëkalimin'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}