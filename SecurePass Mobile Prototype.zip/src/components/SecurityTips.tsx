import { ArrowLeft, Shield, Key, Smartphone, RefreshCw, Eye, Database } from 'lucide-react';

interface SecurityTipsProps {
  onBack: () => void;
}

const tips = [
  {
    icon: Key,
    title: 'Përdor Fjalëkalime të Gjata',
    description: 'Krijo fjalëkalime me të paktën 12-16 karaktere. Fjalëkalimet më të gjata janë eksponencialisht më të vështira për tu thyer.',
  },
  {
    icon: Shield,
    title: 'Mos Përdor Përsëri Fjalëkalimet',
    description: 'Çdo llogari duhet të ketë një fjalëkalim unik. Nëse njëri komprometohet, të tjerët mbeten të sigurt.',
  },
  {
    icon: Smartphone,
    title: 'Aktivizo Autentifikimin Dy-Faktorësh',
    description: 'Shto një shtresë shtesë sigurie me 2FA. Edhe nëse fjalëkalimi juaj vidhet, llogaria juaj mbetet e mbrojtur.',
  },
  {
    icon: RefreshCw,
    title: 'Përditëso Fjalëkalimet Rregullisht',
    description: 'Ndrysho fjalëkalimet e rëndësishme çdo 3-6 muaj, veçanërisht për llogaritë bankare dhe email.',
  },
  {
    icon: Eye,
    title: 'Ruhu nga Phishing-u',
    description: 'Mos e fut kurrë fjalëkalimin tënd në faqe të dyshimta. Verifiko gjithmonë URL-në përpara se të hysh.',
  },
  {
    icon: Database,
    title: 'Përdor një Menaxher Fjalëkalimesh',
    description: 'Po e bën tashmë këtë! Lër SecurePass të mbajë mend fjalëkalime komplekse për ty.',
  },
];

export function SecurityTips({ onBack }: SecurityTipsProps) {
  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Këshilla Sigurie</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-6">
          <p className="text-gray-400">
            Ndiq këto praktika më të mira për të mbajtur jetën tënde digjitale të sigurt.
          </p>
        </div>

        <div className="space-y-4">
          {tips.map((tip, index) => {
            const Icon = tip.icon;
            return (
              <div
                key={index}
                className="bg-gray-800 border border-gray-700 rounded-xl p-4"
              >
                <div className="flex gap-3">
                  <div className="bg-teal-500/20 w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-teal-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-gray-100 mb-1">{tip.title}</h3>
                    <p className="text-gray-400">{tip.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
