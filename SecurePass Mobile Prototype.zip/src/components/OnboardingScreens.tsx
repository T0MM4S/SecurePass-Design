import { useState } from 'react';
import { Shield, Sparkles, Lock, ChevronRight } from 'lucide-react';

interface OnboardingScreensProps {
  onComplete: () => void;
}

export function OnboardingScreens({ onComplete }: OnboardingScreensProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      icon: Shield,
      title: 'Ruaj Fjalëkalimet me Siguri',
      description: 'Mbaji të gjitha fjalëkalimet në një seif të sigurt, të enkriptuar me enkriptim ushtarak.',
    },
    {
      icon: Sparkles,
      title: 'Gjenero Fjalëkalime të Forta',
      description: 'Krijo fjalëkalime të pathyeshme me gjeneratorin tonë të avancuar. Mos përdor më fjalëkalime të dobëta.',
    },
    {
      icon: Lock,
      title: 'Mbro Identitetin Tënd Digjital',
      description: 'Merr njoftime për cenime, këshilla sigurie dhe qëndro i mbrojtur nga kërcënimet kibernetike me SecurePass.',
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  const CurrentIcon = steps[currentStep].icon;

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="relative mb-12">
          <div className="absolute inset-0 bg-teal-500/20 blur-3xl rounded-full"></div>
          <CurrentIcon className="w-24 h-24 text-teal-400 relative z-10" strokeWidth={1.5} />
        </div>

        <div className="text-center mb-12">
          <h2 className="text-gray-100 mb-4">{steps[currentStep].title}</h2>
          <p className="text-gray-400 leading-relaxed max-w-sm">
            {steps[currentStep].description}
          </p>
        </div>

        <div className="flex gap-2 mb-12">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`h-2 rounded-full transition-all ${
                index === currentStep
                  ? 'w-8 bg-teal-500'
                  : 'w-2 bg-gray-700'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="p-6 space-y-3">
        <button
          onClick={handleNext}
          className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          {currentStep < steps.length - 1 ? 'Vazhdo' : 'Fillo'}
          <ChevronRight className="w-5 h-5" />
        </button>
        {currentStep < steps.length - 1 && (
          <button
            onClick={handleSkip}
            className="w-full text-gray-400 hover:text-gray-300 py-2 transition-colors"
          >
            Kalo
          </button>
        )}
      </div>
    </div>
  );
}