import { ArrowLeft, Cloud, CloudUpload, Download, CheckCircle, Clock } from 'lucide-react';

interface BackupSyncProps {
  autoBackup: boolean;
  onToggleAutoBackup: () => void;
  onBack: () => void;
}

export function BackupSync({ autoBackup, onToggleAutoBackup, onBack }: BackupSyncProps) {
  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Backup & Sinkronizim</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="space-y-6">
          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 text-center">
            <Cloud className="w-16 h-16 text-teal-400 mx-auto mb-4" />
            <h3 className="text-gray-100 mb-2">Statusi i Backup në Cloud</h3>
            <div className="flex items-center justify-center gap-2 text-green-400 mb-4">
              <CheckCircle className="w-5 h-5" />
              <span>Backup-i i fundit: 2 orë më parë</span>
            </div>
            <p className="text-gray-400 mb-1">6 fjalëkalime të ruajtur</p>
            <p className="text-gray-500 text-xs">Të enkriptuar me AES-256</p>
          </div>

          <div>
            <h3 className="text-gray-300 mb-3">Cilësimet e Backup</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Backup Automatik</span>
                </div>
                <button
                  onClick={onToggleAutoBackup}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    autoBackup ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      autoBackup ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>
              {autoBackup && (
                <div className="bg-teal-500/10 border border-teal-500/30 rounded-xl p-3">
                  <p className="text-teal-400 text-xs">
                    Fjalëkalimet e tua do të ruhen automatikisht çdo 24 orë
                  </p>
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-gray-300 mb-3">Veprime Manuale</h3>
            <div className="space-y-3">
              <button className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors flex items-center justify-center gap-2">
                <CloudUpload className="w-5 h-5" />
                Ruaj Fjalëkalimet në Cloud
              </button>
              <button className="w-full bg-gray-800 hover:bg-gray-750 border border-gray-700 text-gray-100 py-4 rounded-xl transition-colors flex items-center justify-center gap-2">
                <Download className="w-5 h-5" />
                Rikthe nga Backup
              </button>
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
            <h4 className="text-gray-100 mb-2">Shënim Sigurie</h4>
            <p className="text-gray-400 text-xs leading-relaxed">
              Backup-i juaj është i enkriptuar nga fundi në fund. Vetëm ju mund të dekriptoni dhe të hyni në fjalëkalimet tuaja me fjalëkalimin tuaj kryesor. Ne nuk kemi asnjëherë akses në të dhënat tuaja të pa-enkriptuara.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
