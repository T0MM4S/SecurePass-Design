import { ArrowLeft } from 'lucide-react';
import type { Password } from '../App';

interface CategoryViewProps {
  category: string;
  passwords: Password[];
  onViewPassword: (password: Password) => void;
  onBack: () => void;
}

const categoryLabels: Record<string, string> = {
  'Work': 'Punë',
  'Personal': 'Personal',
  'Social': 'Sociale',
  'Banking': 'Bankare',
};

export function CategoryView({ category, passwords, onViewPassword, onBack }: CategoryViewProps) {
  const categoryLabel = categoryLabels[category] || category;

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">{categoryLabel}</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {passwords.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-gray-400">Nuk ka ende fjalëkalime në këtë kategori</p>
          </div>
        ) : (
          <div className="space-y-3">
            {passwords.map((password) => (
              <button
                key={password.id}
                onClick={() => onViewPassword(password)}
                className="w-full bg-gray-800 hover:bg-gray-750 border border-gray-700 rounded-xl p-4 transition-colors text-left"
              >
                <h3 className="text-gray-100 mb-1">{password.serviceName}</h3>
                <p className="text-gray-400">{password.username}</p>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
