import { useState } from 'react';
import { Shield, Mail, Lock, User, Eye, EyeOff, ArrowLeft } from 'lucide-react';

interface SignupScreenProps {
  onSignup: () => void;
  onBack: () => void;
}

export function SignupScreen({ onSignup, onBack }: SignupScreenProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    onSignup();
  };

  return (
    <div className="h-full flex flex-col bg-gray-900 p-6">
      <button onClick={onBack} className="text-gray-400 hover:text-gray-200 mb-6 flex items-center">
        <ArrowLeft className="w-5 h-5 mr-2" />
        Kthehu
      </button>

      <div className="flex-1 flex flex-col justify-center">
        <div className="flex flex-col items-center mb-8">
          <Shield className="w-16 h-16 text-teal-400 mb-4" strokeWidth={1.5} />
          <h2 className="text-teal-400 mb-2">Krijo Llogari</h2>
          <p className="text-gray-400">Siguro jetën tënde digjitale</p>
        </div>

        <form onSubmit={handleSignup} className="space-y-4">
          <div>
            <label className="block text-gray-300 mb-2">Emri i Plotë</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Vendos emrin tënd"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-4 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 mb-2">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Vendos email-in tënd"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-4 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 mb-2">Fjalëkalimi Kryesor</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Krijo një fjalëkalim të fortë"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-4 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 mb-2">Konfirmo Fjalëkalimin</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Konfirmo fjalëkalimin tënd"
                className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-4 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors mt-6"
          >
            Krijo Llogari
          </button>
        </form>
      </div>
    </div>
  );
}