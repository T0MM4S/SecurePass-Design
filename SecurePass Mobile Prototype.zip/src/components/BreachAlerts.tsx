import { ArrowLeft, AlertTriangle, AlertCircle, CheckCircle } from 'lucide-react';

interface BreachAlertsProps {
  onBack: () => void;
}

const alerts = [
  {
    id: '1',
    severity: 'high',
    title: 'Email-i u gjet në cenimin e të dhënave',
    description: 'Email-i juaj john.doe@gmail.com u gjet në cenimin e LinkedIn (2021).',
    action: 'Ndrysho fjalëkalimet e prekura',
    date: '2 ditë më parë',
  },
  {
    id: '2',
    severity: 'medium',
    title: 'U zbulua fjalëkalim i dobët',
    description: 'Fjalëkalimi juaj i Instagram është i dobët dhe duhet të përditësohet menjëherë.',
    action: 'Përditëso fjalëkalimin',
    date: '1 javë më parë',
  },
  {
    id: '3',
    severity: 'low',
    title: 'U zbulua përdorim i përsëritur i fjalëkalimit',
    description: 'Po përdorni të njëjtin fjalëkalim për Netflix dhe Spotify.',
    action: 'Përdor fjalëkalime unike',
    date: '2 javë më parë',
  },
  {
    id: '4',
    severity: 'resolved',
    title: 'Problemi i sigurisë u zgjidh',
    description: 'Përditësuat me sukses fjalëkalimin tuaj të GitHub.',
    action: 'Shiko detajet',
    date: '3 javë më parë',
  },
];

export function BreachAlerts({ onBack }: BreachAlertsProps) {
  const getSeverityStyles = (severity: string) => {
    switch (severity) {
      case 'high':
        return {
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          icon: <AlertTriangle className="w-5 h-5 text-red-400" />,
          iconBg: 'bg-red-500/20',
          text: 'text-red-400',
        };
      case 'medium':
        return {
          bg: 'bg-orange-500/10',
          border: 'border-orange-500/30',
          icon: <AlertCircle className="w-5 h-5 text-orange-400" />,
          iconBg: 'bg-orange-500/20',
          text: 'text-orange-400',
        };
      case 'low':
        return {
          bg: 'bg-yellow-500/10',
          border: 'border-yellow-500/30',
          icon: <AlertCircle className="w-5 h-5 text-yellow-400" />,
          iconBg: 'bg-yellow-500/20',
          text: 'text-yellow-400',
        };
      default:
        return {
          bg: 'bg-gray-800',
          border: 'border-gray-700',
          icon: <CheckCircle className="w-5 h-5 text-green-400" />,
          iconBg: 'bg-green-500/20',
          text: 'text-green-400',
        };
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Njoftimet për Cenime</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-6">
          <p className="text-gray-400">
            Qëndro i informuar për kërcënimet e sigurisë dhe cenimet që ndikojnë llogaritë e tua.
          </p>
        </div>

        <div className="space-y-4">
          {alerts.map((alert) => {
            const styles = getSeverityStyles(alert.severity);
            return (
              <div
                key={alert.id}
                className={`${styles.bg} border ${styles.border} rounded-xl p-4`}
              >
                <div className="flex gap-3">
                  <div className={`${styles.iconBg} w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0`}>
                    {styles.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-gray-100 mb-1">{alert.title}</h3>
                    <p className="text-gray-400 mb-2">{alert.description}</p>
                    <div className="flex items-center justify-between">
                      <button className={`${styles.text} hover:underline`}>
                        {alert.action} →
                      </button>
                      <span className="text-gray-500 text-xs">{alert.date}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
