import { useState } from 'react';
import { Plus, Search, Home, Grid3x3, User, Settings } from 'lucide-react';
import { calculatePasswordStrength } from './PasswordStrength';
import type { Password, Screen } from '../App';

interface HomeDashboardProps {
  passwords: Password[];
  onAddPassword: () => void;
  onViewPassword: (password: Password) => void;
  onNavigate: (screen: Screen) => void;
}

export function HomeDashboard({
  passwords,
  onAddPassword,
  onViewPassword,
  onNavigate,
}: HomeDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPasswords = passwords.filter(
    (password) =>
      password.serviceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      password.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      password.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 pb-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-gray-100">Fjalëkalimet e Mia</h2>
            <p className="text-gray-400">{passwords.length} të ruajtura</p>
          </div>
          <button
            onClick={onAddPassword}
            className="bg-teal-500 hover:bg-teal-600 text-white p-3 rounded-xl transition-colors"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Kërko fjalëkalime..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-800 text-gray-100 rounded-xl px-12 py-3 border border-gray-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        {filteredPasswords.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-gray-400">
              {searchQuery ? 'Nuk u gjet asnjë fjalëkalim' : 'Ende nuk ka fjalëkalime'}
            </p>
            {!searchQuery && (
              <button
                onClick={onAddPassword}
                className="mt-4 text-teal-400 hover:text-teal-300"
              >
                Shto fjalëkalimin e parë
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredPasswords.map((password) => {
              const strength = calculatePasswordStrength(password.password);
              return (
                <button
                  key={password.id}
                  onClick={() => onViewPassword(password)}
                  className="w-full bg-gray-800 hover:bg-gray-750 border border-gray-700 rounded-xl p-4 transition-colors text-left"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-gray-100 mb-1 truncate">{password.serviceName}</h3>
                      <p className="text-gray-400 truncate">{password.username}</p>
                    </div>
                    <span className="inline-block bg-teal-500/20 text-teal-400 px-3 py-1 rounded-lg ml-2 flex-shrink-0">
                      {password.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-gray-700 rounded-full h-1.5 overflow-hidden">
                      <div
                        className={`${strength.bgColor} h-full transition-all duration-300`}
                        style={{ width: `${strength.score}%` }}
                      />
                    </div>
                    <span className={`${strength.color} text-xs flex-shrink-0`}>
                      {strength.level}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 px-6 py-4">
        <div className="flex items-center justify-around">
          <button
            onClick={() => onNavigate('home')}
            className="flex flex-col items-center text-teal-400"
          >
            <Home className="w-6 h-6 mb-1" />
            <span className="text-xs">Kreu</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Grid3x3 className="w-6 h-6 mb-1" />
            <span className="text-xs">Kategoritë</span>
          </button>
          <button
            onClick={() => onNavigate('profile')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <User className="w-6 h-6 mb-1" />
            <span className="text-xs">Profili</span>
          </button>
          <button
            onClick={() => onNavigate('settings')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Settings className="w-6 h-6 mb-1" />
            <span className="text-xs">Cilësimet</span>
          </button>
        </div>
      </div>
    </div>
  );
}