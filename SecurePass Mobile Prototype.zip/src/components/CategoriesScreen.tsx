import { Briefcase, User, Hash, CreditCard, Home, Grid3x3, Settings } from 'lucide-react';
import type { Password, Screen } from '../App';

interface CategoriesScreenProps {
  passwords: Password[];
  onViewCategory: (category: string) => void;
  onNavigate: (screen: Screen) => void;
}

const categories = [
  { name: 'Work', icon: Briefcase, color: 'bg-blue-500', label: 'Punë' },
  { name: 'Personal', icon: User, color: 'bg-teal-500', label: 'Personal' },
  { name: 'Social', icon: Hash, color: 'bg-purple-500', label: 'Sociale' },
  { name: 'Banking', icon: CreditCard, color: 'bg-green-500', label: 'Bankare' },
];

export function CategoriesScreen({ passwords, onViewCategory, onNavigate }: CategoriesScreenProps) {
  const getCategoryCount = (category: string) => {
    return passwords.filter((p) => p.category === category).length;
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 pb-4">
        <h2 className="text-gray-100 mb-2">Kategoritë</h2>
        <p className="text-gray-400">Organizo fjalëkalimet e tua</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        <div className="grid grid-cols-2 gap-4">
          {categories.map((category) => {
            const Icon = category.icon;
            const count = getCategoryCount(category.name);
            return (
              <button
                key={category.name}
                onClick={() => onViewCategory(category.name)}
                className="bg-gray-800 hover:bg-gray-750 border border-gray-700 rounded-2xl p-6 transition-colors"
              >
                <div className={`${category.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-gray-100 mb-1">{category.label}</h3>
                <p className="text-gray-400">{count} artikuj</p>
              </button>
            );
          })}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 px-6 py-4">
        <div className="flex items-center justify-around">
          <button
            onClick={() => onNavigate('home')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Home className="w-6 h-6 mb-1" />
            <span className="text-xs">Kreu</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center text-teal-400"
          >
            <Grid3x3 className="w-6 h-6 mb-1" />
            <span className="text-xs">Kategoritë</span>
          </button>
          <button
            onClick={() => onNavigate('profile')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <User className="w-6 h-6 mb-1" />
            <span className="text-xs">Profili</span>
          </button>
          <button
            onClick={() => onNavigate('settings')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Settings className="w-6 h-6 mb-1" />
            <span className="text-xs">Cilësimet</span>
          </button>
        </div>
      </div>
    </div>
  );
}
