import { Home, Grid3x3, User, Settings, Moon, Lock, Shield, Info, LogOut, AlertTriangle, Cloud, Fingerprint, Activity } from 'lucide-react';
import type { Screen } from '../App';

interface SettingsScreenProps {
  darkMode: boolean;
  twoFactorEnabled: boolean;
  biometricEnabled: boolean;
  onToggleDarkMode: () => void;
  onToggleTwoFactor: () => void;
  onToggleBiometric: () => void;
  onNavigate: (screen: Screen) => void;
}

export function SettingsScreen({
  darkMode,
  twoFactorEnabled,
  biometricEnabled,
  onToggleDarkMode,
  onToggleTwoFactor,
  onToggleBiometric,
  onNavigate,
}: SettingsScreenProps) {
  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 pb-4">
        <h2 className="text-gray-100 mb-2">Cilësimet</h2>
        <p className="text-gray-400">Menaxho preferencat e tua</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        <div className="space-y-6">
          <div>
            <h3 className="text-gray-300 mb-3">Pamja</h3>
            <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
              <div className="flex items-center gap-3">
                <Moon className="w-5 h-5 text-teal-400" />
                <span className="text-gray-100">Mënyra e Errët</span>
              </div>
              <button
                onClick={onToggleDarkMode}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  darkMode ? 'bg-teal-500' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                    darkMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                ></div>
              </button>
            </div>
          </div>

          <div>
            <h3 className="text-gray-300 mb-3">Siguria</h3>
            <div className="space-y-3">
              <button
                onClick={() => onNavigate('master-password-reset')}
                className="w-full flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4 hover:bg-gray-750 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Ndrysho Fjalëkalimin Kryesor</span>
                </div>
                <span className="text-gray-500">{'>'}</span>
              </button>

              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Autentifikimi Dy-Faktorësh</span>
                </div>
                <button
                  onClick={onToggleTwoFactor}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    twoFactorEnabled ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      twoFactorEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>

              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <Fingerprint className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Zhbllokimi Biometrik</span>
                </div>
                <button
                  onClick={onToggleBiometric}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    biometricEnabled ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      biometricEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-gray-300 mb-3">Të Avancuara</h3>
            <div className="space-y-3">
              <button
                onClick={() => onNavigate('breach-alerts')}
                className="w-full flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4 hover:bg-gray-750 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-teal-400" />
                  <div>
                    <p className="text-gray-100">Njoftimet për Cenime</p>
                    <p className="text-red-400 text-xs">3 njoftime të reja</p>
                  </div>
                </div>
                <span className="text-gray-500">{'>'}</span>
              </button>

              <button
                onClick={() => onNavigate('activity-log')}
                className="w-full flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4 hover:bg-gray-750 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <Activity className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Ditari i Aktivitetit</span>
                </div>
                <span className="text-gray-500">{'>'}</span>
              </button>

              <button
                onClick={() => onNavigate('backup-sync')}
                className="w-full flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4 hover:bg-gray-750 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <Cloud className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Backup & Sinkronizim</span>
                </div>
                <span className="text-gray-500">{'>'}</span>
              </button>

              <button
                onClick={() => onNavigate('security-tips')}
                className="w-full flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4 hover:bg-gray-750 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <Info className="w-5 h-5 text-teal-400" />
                  <span className="text-gray-100">Këshilla Sigurie</span>
                </div>
                <span className="text-gray-500">{'>'}</span>
              </button>
            </div>
          </div>

          <button className="w-full flex items-center justify-center gap-2 bg-red-500/10 text-red-400 border border-red-500/30 rounded-xl p-4 hover:bg-red-500/20 transition-colors">
            <LogOut className="w-5 h-5" />
            <span>Dil</span>
          </button>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 px-6 py-4">
        <div className="flex items-center justify-around">
          <button
            onClick={() => onNavigate('home')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Home className="w-6 h-6 mb-1" />
            <span className="text-xs">Kreu</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Grid3x3 className="w-6 h-6 mb-1" />
            <span className="text-xs">Kategoritë</span>
          </button>
          <button
            onClick={() => onNavigate('profile')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <User className="w-6 h-6 mb-1" />
            <span className="text-xs">Profili</span>
          </button>
          <button
            onClick={() => onNavigate('settings')}
            className="flex flex-col items-center text-teal-400"
          >
            <Settings className="w-6 h-6 mb-1" />
            <span className="text-xs">Cilësimet</span>
          </button>
        </div>
      </div>
    </div>
  );
}
