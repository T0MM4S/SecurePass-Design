export interface PasswordStrengthResult {
  score: number; // 0-100
  level: 'I dobët' | 'I pranueshëm' | 'I mirë' | 'I fortë' | 'Shumë i fortë';
  color: string;
  bgColor: string;
  feedback: string[];
}

export function calculatePasswordStrength(password: string): PasswordStrengthResult {
  if (!password) {
    return {
      score: 0,
      level: 'I dobët',
      color: 'text-red-400',
      bgColor: 'bg-red-500',
      feedback: ['Fjalëkalimi është bosh'],
    };
  }

  let score = 0;
  const feedback: string[] = [];

  // Length check
  if (password.length >= 8) score += 20;
  if (password.length >= 12) score += 10;
  if (password.length >= 16) score += 10;
  if (password.length < 8) feedback.push('Përdor të paktën 8 karaktere');

  // Lowercase letters
  if (/[a-z]/.test(password)) {
    score += 10;
  } else {
    feedback.push('Shto shkronja të vogla');
  }

  // Uppercase letters
  if (/[A-Z]/.test(password)) {
    score += 10;
  } else {
    feedback.push('Shto shkronja të mëdha');
  }

  // Numbers
  if (/[0-9]/.test(password)) {
    score += 10;
  } else {
    feedback.push('Shto numra');
  }

  // Special characters
  if (/[^a-zA-Z0-9]/.test(password)) {
    score += 15;
  } else {
    feedback.push('Shto karaktere speciale');
  }

  // Character variety
  const uniqueChars = new Set(password).size;
  if (uniqueChars >= password.length * 0.6) score += 10;

  // No common patterns
  const commonPatterns = [
    /^[0-9]+$/,
    /^[a-z]+$/i,
    /^(.)\1+$/,
    /123|234|345|456|567|678|789|890/,
    /abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz/i,
    /password|qwerty|admin|letmein|welcome|monkey|dragon/i,
  ];

  let hasCommonPattern = false;
  for (const pattern of commonPatterns) {
    if (pattern.test(password)) {
      hasCommonPattern = true;
      feedback.push('Shmang modelet e zakonshme');
      break;
    }
  }

  if (!hasCommonPattern) score += 15;

  // Determine level and color
  let level: PasswordStrengthResult['level'];
  let color: string;
  let bgColor: string;

  if (score < 30) {
    level = 'I dobët';
    color = 'text-red-400';
    bgColor = 'bg-red-500';
  } else if (score < 50) {
    level = 'I pranueshëm';
    color = 'text-orange-400';
    bgColor = 'bg-orange-500';
  } else if (score < 70) {
    level = 'I mirë';
    color = 'text-yellow-400';
    bgColor = 'bg-yellow-500';
  } else if (score < 85) {
    level = 'I fortë';
    color = 'text-teal-400';
    bgColor = 'bg-teal-500';
  } else {
    level = 'Shumë i fortë';
    color = 'text-green-400';
    bgColor = 'bg-green-500';
  }

  return { score, level, color, bgColor, feedback };
}

interface PasswordStrengthIndicatorProps {
  password: string;
  showDetails?: boolean;
}

export function PasswordStrengthIndicator({
  password,
  showDetails = false,
}: PasswordStrengthIndicatorProps) {
  const strength = calculatePasswordStrength(password);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-gray-400">Fuqia e Fjalëkalimit</span>
        <span className={strength.color}>{strength.level}</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className={`${strength.bgColor} h-full transition-all duration-300 rounded-full`}
          style={{ width: `${strength.score}%` }}
        />
      </div>
      {showDetails && strength.feedback.length > 0 && (
        <div className="mt-2 space-y-1">
          {strength.feedback.map((tip, index) => (
            <p key={index} className="text-gray-400 text-sm">
              • {tip}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}
