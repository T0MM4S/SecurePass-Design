import { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCw, Copy, Check } from 'lucide-react';
import { PasswordStrengthIndicator } from './PasswordStrength';

interface PasswordGeneratorProps {
  onBack: () => void;
  onUsePassword?: (password: string) => void;
  showUseButton?: boolean;
}

export function PasswordGenerator({ onBack, onUsePassword, showUseButton = false }: PasswordGeneratorProps) {
  const [length, setLength] = useState(16);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [includeUppercase, setIncludeUppercase] = useState(true);
  const [includeLowercase, setIncludeLowercase] = useState(true);
  const [generatedPassword, setGeneratedPassword] = useState('');
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    let chars = '';
    let requiredChars = '';

    if (includeLowercase) {
      chars += lowercase;
      requiredChars += lowercase[Math.floor(Math.random() * lowercase.length)];
    }
    if (includeUppercase) {
      chars += uppercase;
      requiredChars += uppercase[Math.floor(Math.random() * uppercase.length)];
    }
    if (includeNumbers) {
      chars += numbers;
      requiredChars += numbers[Math.floor(Math.random() * numbers.length)];
    }
    if (includeSymbols) {
      chars += symbols;
      requiredChars += symbols[Math.floor(Math.random() * symbols.length)];
    }

    if (chars === '') chars = lowercase;

    let password = requiredChars;
    for (let i = requiredChars.length; i < length; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    // Shuffle the password
    password = password
      .split('')
      .sort(() => Math.random() - 0.5)
      .join('');

    setGeneratedPassword(password);
  };

  useEffect(() => {
    generatePassword();
  }, [length, includeNumbers, includeSymbols, includeUppercase, includeLowercase]);

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleUsePassword = () => {
    if (onUsePassword) {
      onUsePassword(generatedPassword);
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="text-gray-400 hover:text-gray-200">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h2 className="text-gray-100">Gjeneratori i Fjalëkalimeve</h2>
          <div className="w-6"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="space-y-6">
          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
            <div className="bg-gray-900 rounded-xl p-4 mb-4 font-mono text-teal-400 break-all min-h-[60px] flex items-center">
              {generatedPassword || 'Kliko gjenero'}
            </div>
            <div className="mb-4">
              <PasswordStrengthIndicator password={generatedPassword} />
            </div>
            <div className="flex gap-3">
              <button
                onClick={generatePassword}
                className="flex-1 bg-teal-500 hover:bg-teal-600 text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                Gjenero
              </button>
              <button
                onClick={handleCopy}
                className="bg-gray-700 hover:bg-gray-600 text-teal-400 px-6 py-3 rounded-xl transition-colors flex items-center gap-2"
              >
                {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
            {showUseButton && (
              <button
                onClick={handleUsePassword}
                className="w-full mt-3 bg-gray-700 hover:bg-gray-600 text-gray-100 py-3 rounded-xl transition-colors"
              >
                Përdor Këtë Fjalëkalim
              </button>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-gray-300">Gjatësia</label>
                <span className="text-teal-400">{length}</span>
              </div>
              <input
                type="range"
                min="8"
                max="32"
                value={length}
                onChange={(e) => setLength(Number(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
              />
              <div className="flex justify-between text-gray-500 mt-1">
                <span>8</span>
                <span>32</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <label className="text-gray-300">Përfshi Numra</label>
                <button
                  type="button"
                  onClick={() => setIncludeNumbers(!includeNumbers)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    includeNumbers ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      includeNumbers ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>

              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <label className="text-gray-300">Përfshi Simbole</label>
                <button
                  type="button"
                  onClick={() => setIncludeSymbols(!includeSymbols)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    includeSymbols ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      includeSymbols ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>

              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <label className="text-gray-300">Përfshi Shkronja të Mëdha</label>
                <button
                  type="button"
                  onClick={() => setIncludeUppercase(!includeUppercase)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    includeUppercase ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      includeUppercase ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>

              <div className="flex items-center justify-between bg-gray-800 border border-gray-700 rounded-xl p-4">
                <label className="text-gray-300">Përfshi Shkronja të Vogla</label>
                <button
                  type="button"
                  onClick={() => setIncludeLowercase(!includeLowercase)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    includeLowercase ? 'bg-teal-500' : 'bg-gray-600'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform absolute top-0.5 ${
                      includeLowercase ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}