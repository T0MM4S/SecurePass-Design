import { Shield, Fingerprint, ScanFace } from 'lucide-react';

interface BiometricUnlockProps {
  onUnlock: () => void;
  onSkip: () => void;
}

export function BiometricUnlock({ onUnlock, onSkip }: BiometricUnlockProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-teal-900 p-8">
      <div className="flex flex-col items-center space-y-8">
        <div className="relative">
          <div className="absolute inset-0 bg-teal-500/20 blur-3xl rounded-full"></div>
          <Shield className="w-20 h-20 text-teal-400 relative z-10 mb-4" strokeWidth={1.5} />
        </div>
        
        <div className="text-center">
          <h2 className="text-gray-100 mb-2">Zhblloko SecurePass</h2>
          <p className="text-gray-400">Përdor biometrinë për të hyrë në seifin tënd</p>
        </div>

        <div className="flex gap-6 mt-8">
          <button
            onClick={onUnlock}
            className="flex flex-col items-center gap-3 bg-gray-800 hover:bg-gray-750 border border-gray-700 rounded-2xl p-8 transition-colors"
          >
            <ScanFace className="w-12 h-12 text-teal-400" />
            <span className="text-gray-300">Face ID</span>
          </button>
          
          <button
            onClick={onUnlock}
            className="flex flex-col items-center gap-3 bg-gray-800 hover:bg-gray-750 border border-gray-700 rounded-2xl p-8 transition-colors"
          >
            <Fingerprint className="w-12 h-12 text-teal-400" />
            <span className="text-gray-300">Gjurmë gishtash</span>
          </button>
        </div>

        <button
          onClick={onSkip}
          className="mt-8 text-gray-400 hover:text-gray-300 transition-colors"
        >
          Përdor fjalëkalimin kryesor në vend
        </button>
      </div>
    </div>
  );
}