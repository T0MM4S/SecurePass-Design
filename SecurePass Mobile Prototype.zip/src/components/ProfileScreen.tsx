import { Home, Grid3x3, User, Settings, Mail, Shield } from 'lucide-react';
import type { Screen } from '../App';

interface ProfileScreenProps {
  profile: {
    name: string;
    email: string;
  };
  onNavigate: (screen: Screen) => void;
}

export function ProfileScreen({ profile, onNavigate }: ProfileScreenProps) {
  return (
    <div className="h-full flex flex-col bg-gray-900">
      <div className="p-6 pb-4">
        <h2 className="text-gray-100 mb-2">Profili</h2>
        <p className="text-gray-400">Informacioni i llogarisë suaj</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        <div className="space-y-6">
          <div className="flex flex-col items-center py-8">
            <div className="w-24 h-24 bg-teal-500 rounded-full flex items-center justify-center mb-4">
              <User className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-gray-100 mb-1">{profile.name}</h3>
            <p className="text-gray-400">{profile.email}</p>
          </div>

          <div className="space-y-3">
            <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
              <div className="flex items-center gap-4">
                <div className="bg-gray-700 w-12 h-12 rounded-xl flex items-center justify-center">
                  <Mail className="w-6 h-6 text-teal-400" />
                </div>
                <div className="flex-1">
                  <p className="text-gray-400">Email</p>
                  <p className="text-gray-100">{profile.email}</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800 border border-gray-700 rounded-xl p-4">
              <div className="flex items-center gap-4">
                <div className="bg-gray-700 w-12 h-12 rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-teal-400" />
                </div>
                <div className="flex-1">
                  <p className="text-gray-400">Statusi i Llogarisë</p>
                  <p className="text-teal-400">I siguruar</p>
                </div>
              </div>
            </div>
          </div>

          <button className="w-full bg-teal-500 hover:bg-teal-600 text-white py-4 rounded-xl transition-colors">
            Ndrysho Profilin
          </button>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 px-6 py-4">
        <div className="flex items-center justify-around">
          <button
            onClick={() => onNavigate('home')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Home className="w-6 h-6 mb-1" />
            <span className="text-xs">Kreu</span>
          </button>
          <button
            onClick={() => onNavigate('categories')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Grid3x3 className="w-6 h-6 mb-1" />
            <span className="text-xs">Kategoritë</span>
          </button>
          <button
            onClick={() => onNavigate('profile')}
            className="flex flex-col items-center text-teal-400"
          >
            <User className="w-6 h-6 mb-1" />
            <span className="text-xs">Profili</span>
          </button>
          <button
            onClick={() => onNavigate('settings')}
            className="flex flex-col items-center text-gray-400 hover:text-gray-200"
          >
            <Settings className="w-6 h-6 mb-1" />
            <span className="text-xs">Cilësimet</span>
          </button>
        </div>
      </div>
    </div>
  );
}
